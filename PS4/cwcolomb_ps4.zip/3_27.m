function 3_27()
    K = 109; a = 67; % Compensator parameters
    sys = tf(
end